#!/bin/bash

rm -rf ~/.local/share/Trash/*
echo "Trash cleared!"